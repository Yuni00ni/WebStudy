console.log("외부 방식으로 작성!");
